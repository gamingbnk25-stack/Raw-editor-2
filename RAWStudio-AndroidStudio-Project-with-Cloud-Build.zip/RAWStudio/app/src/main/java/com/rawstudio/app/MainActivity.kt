package com.rawstudio.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.pow

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFFFF8A3D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RawStudioApp() }
    }
}

data class EditSettings(
    val exposure: Float = 0f, val saturation: Float = 1f, val contrast: Float = 1f,
    val sharpen: Float = 0f, val denoise: Float = 0f, val highlights: Float = 0f,
    val shadows: Float = 0f, val preset: String = "Original"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RawStudioApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var settings by remember { mutableStateOf(EditSettings()) }
    var status by remember { mutableStateOf("Choose a photo to start editing") }
    var aiSuggestion by remember { mutableStateOf("AI suggestions will appear here.") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            status = "Loading image…"
            val bmp = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            source = bmp
            settings = EditSettings()
            preview = bmp?.let { PhotoEngine.apply(it, settings) }
            status = if (bmp == null) "Could not decode this image. Try a JPEG or PNG." else "Photo loaded"
        }
    }

    fun update(newSettings: EditSettings) {
        settings = newSettings
        val original = source ?: return
        scope.launch(Dispatchers.Default) {
            val edited = PhotoEngine.apply(original, newSettings)
            withContext(Dispatchers.Main) { preview = edited }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Panel, onBackground = Color.White,
        onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = { Column { Text("RAW STUDIO", fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("PHOTO LAB", fontSize = 10.sp, color = Color.Gray) } },
                actions = {
                    IconButton(onClick = { source?.let { update(EditSettings()) } }) { Icon(Icons.Default.Restore, "Reset") }
                    IconButton(onClick = {
                        val bmp = preview
                        if (bmp != null) scope.launch {
                            status = saveBitmap(context, bmp)
                        } else status = "Import a photo first"
                    }) { Icon(Icons.Default.FileDownload, "Export") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("EDITOR", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(status, color = Color.Gray, fontSize = 11.sp)
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.fillMaxWidth().weight(1f).background(Color(0xFF08090B), RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (preview != null) Image(
                        bitmap = preview!!.asImageBitmap(), contentDescription = "Edited photo",
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit
                    ) else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Color.Gray, modifier = Modifier.size(54.dp))
                        Text("Your photo appears here", color = Color.Gray)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { picker.launch("image/*") }) { Text("Import photo") }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("Original", "Vivid", "Film", "De-Log", "Sharpen").forEach { name ->
                        FilterChip(selected = settings.preset == name, onClick = {
                            update(settings.copy(preset = name, sharpen = if (name == "Sharpen") .7f else settings.sharpen))
                        }, label = { Text(name) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("LIGHT & COLOR", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                EditSlider("Exposure", settings.exposure, -2f, 2f, "EV") { update(settings.copy(exposure = it)) }
                EditSlider("Saturation", settings.saturation, 0f, 2f, "") { update(settings.copy(saturation = it)) }
                EditSlider("Contrast", settings.contrast, .5f, 1.8f, "") { update(settings.copy(contrast = it)) }
                EditSlider("Highlights", settings.highlights, -1f, 1f, "") { update(settings.copy(highlights = it)) }
                EditSlider("Shadows", settings.shadows, -1f, 1f, "") { update(settings.copy(shadows = it)) }
                Text("DETAIL", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                EditSlider("Sharpen", settings.sharpen, 0f, 1f, "") { update(settings.copy(sharpen = it)) }
                EditSlider("Denoise", settings.denoise, 0f, 1f, "") { update(settings.copy(denoise = it)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = {
                        aiSuggestion = PhotoEngine.suggest(settings)
                        status = "Offline analysis complete"
                    }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(5.dp)); Text("AI suggest") }
                    Button(onClick = {
                        val suggested = PhotoEngine.autoEnhance(settings)
                        update(suggested)
                        aiSuggestion = "Applied an offline smart enhancement. Adjust the sliders to taste."
                    }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(5.dp)); Text("AI enhance") }
                }
                Text(aiSuggestion, color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 7.dp))
                Text("Online AI: connect your own HTTPS enhancement API in AiEnhancer.kt. No API key is bundled.", color = Color.Gray, fontSize = 10.sp)
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Choose another photo") }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun EditSlider(label: String, value: Float, min: Float, max: Float, suffix: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp)
            Text("${"%.2f".format(value)} $suffix", color = Color.LightGray, fontSize = 11.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = min..max)
    }
}

object PhotoEngine {
    fun apply(input: Bitmap, s: EditSettings): Bitmap {
        val w = input.width.coerceAtMost(1800)
        val h = (input.height * (w.toFloat() / input.width)).toInt().coerceAtLeast(1)
        val scaled = if (w != input.width) Bitmap.createScaledBitmap(input, w, h, true) else input
        val pixels = IntArray(scaled.width * scaled.height)
        scaled.getPixels(pixels, 0, scaled.width, 0, 0, scaled.width, scaled.height)
        val exposure = 2.0.pow(s.exposure.toDouble()).toFloat()
        for (i in pixels.indices) {
            val c = pixels[i]
            var r = ((c shr 16 and 255) * exposure).coerceIn(0f, 255f)
            var g = ((c shr 8 and 255) * exposure).coerceIn(0f, 255f)
            var b = ((c and 255) * exposure).coerceIn(0f, 255f)
            val avg = (r + g + b) / 3f
            val contrast = s.contrast
            r = ((r - 128f) * contrast + 128f)
            g = ((g - 128f) * contrast + 128f)
            b = ((b - 128f) * contrast + 128f)
            val sat = when (s.preset) {
                "Vivid" -> s.saturation * 1.25f
                "Film" -> s.saturation * .82f
                "De-Log" -> s.saturation * 1.15f
                else -> s.saturation
            }
            r = (avg + (r - avg) * sat).coerceIn(0f, 255f)
            g = (avg + (g - avg) * sat).coerceIn(0f, 255f)
            b = (avg + (b - avg) * sat).coerceIn(0f, 255f)
            if (s.preset == "Film") { r = (r * 1.04f + 4).coerceIn(0f,255f); b = (b * .94f).coerceIn(0f,255f) }
            if (s.preset == "De-Log") { r = (r - 8f).coerceIn(0f,255f); g = (g - 5f).coerceIn(0f,255f); b = (b - 3f).coerceIn(0f,255f) }
            val lum = (r + g + b) / 3f
            val shadowFactor = (1f - lum / 255f)
            val highlightFactor = lum / 255f
            r = (r + s.shadows * shadowFactor * 35f - s.highlights * highlightFactor * 30f).coerceIn(0f,255f)
            g = (g + s.shadows * shadowFactor * 35f - s.highlights * highlightFactor * 30f).coerceIn(0f,255f)
            b = (b + s.shadows * shadowFactor * 35f - s.highlights * highlightFactor * 30f).coerceIn(0f,255f)
            pixels[i] = (c and -0x1000000) or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt()
        }
        // Lightweight 3x3 neighborhood filter: denoise blends toward a local average;
        // sharpening adds high-frequency detail back from the original pixel.
        if (s.denoise > 0f || s.sharpen > 0f) {
            val filtered = pixels.copyOf()
            val width = scaled.width
            val height = scaled.height
            for (y in 1 until height - 1) {
                for (x in 1 until width - 1) {
                    val idx = y * width + x
                    var rr = 0; var gg = 0; var bb = 0
                    for (dy in -1..1) for (dx in -1..1) {
                        val q = pixels[(y + dy) * width + (x + dx)]
                        rr += (q shr 16) and 255
                        gg += (q shr 8) and 255
                        bb += q and 255
                    }
                    val center = pixels[idx]
                    val blurR = rr / 9f; val blurG = gg / 9f; val blurB = bb / 9f
                    fun channel(shift: Int, blur: Float): Int {
                        val original = ((center shr shift) and 255).toFloat()
                        val denoised = original * (1f - s.denoise * .75f) + blur * (s.denoise * .75f)
                        return (denoised + (original - blur) * s.sharpen * 1.4f).toInt().coerceIn(0, 255)
                    }
                    filtered[idx] = (center and -0x1000000) or
                        (channel(16, blurR) shl 16) or (channel(8, blurG) shl 8) or channel(0, blurB)
                }
            }
            for (i in pixels.indices) pixels[i] = filtered[i]
        }
        val out = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, scaled.width, 0, 0, scaled.width, scaled.height)
        return out
    }

    fun suggest(s: EditSettings): String = when {
        s.exposure < -.4f -> "Suggestion: raise exposure slightly to reveal darker details."
        s.saturation < .75f -> "Suggestion: increase saturation for a more lively colour palette."
        s.contrast < .85f -> "Suggestion: add a little contrast for stronger tonal separation."
        else -> "Suggestion: try Vivid for punchy colours, Film for a softer cinematic mood, or a touch of denoise for low-light images."
    }

    fun autoEnhance(s: EditSettings) = s.copy(
        exposure = (s.exposure + .15f).coerceIn(-2f, 2f),
        saturation = (s.saturation * 1.12f).coerceIn(0f, 2f),
        contrast = (s.contrast * 1.08f).coerceIn(.5f, 1.8f)
    )
}

private fun saveBitmap(context: android.content.Context, bitmap: Bitmap): String {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "RAWStudio_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RAW Studio")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: return "Export failed"
    return try {
        context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        "Saved to Pictures/RAW Studio"
    } catch (e: Exception) { "Export failed: ${e.message}" }
}
