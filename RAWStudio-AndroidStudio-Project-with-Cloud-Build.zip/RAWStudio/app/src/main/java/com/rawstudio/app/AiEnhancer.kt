package com.rawstudio.app

/**
 * Online AI integration boundary.
 *
 * Provide an HTTPS endpoint you control, then implement the request/response contract below.
 * Never hard-code a secret API key in an Android app; mobile APKs can be reverse engineered.
 *
 * Suggested contract:
 * POST multipart/form-data:
 *   image=<JPEG bytes>
 *   task=enhance | suggest
 * Response:
 *   enhance: image/jpeg bytes
 *   suggest: application/json { "suggestion": "..." }
 *
 * Offline AI in this starter is a local heuristic auto-enhancer and edit suggester in PhotoEngine.
 * A true on-device ML model (e.g. TFLite) and a hosted AI service require model/API credentials
 * and have deliberately not been represented as already implemented.
 */
interface OnlineAiEnhancer {
    suspend fun enhance(jpeg: ByteArray): ByteArray
    suspend fun suggest(jpeg: ByteArray): String
}
