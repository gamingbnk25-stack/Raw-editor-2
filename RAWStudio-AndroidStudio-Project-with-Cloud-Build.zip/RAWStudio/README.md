# RAW Studio — Android Studio project

A Kotlin + Jetpack Compose starter photo editor for Android.

## Included
- Import photos through Android's system photo picker.
- Vivid, Film, De-Log-look and Sharpen presets.
- Exposure, saturation, contrast, highlights, shadows, sharpen and denoise controls.
- Local/offline heuristic AI-style auto-enhance and editing suggestions.
- JPEG export to `Pictures/RAW Studio`.
- Non-destructive editing controls (the original imported bitmap is retained in memory).

## Open and build
1. Install Android Studio (Ladybug or newer) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Run the `app` configuration on an Android 8.0+ device or emulator.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important limitations — read before publishing
- This is a source project ZIP, **not a prebuilt APK**. It has not been compiled or device-tested in this environment.
- Current image import decodes standard formats supported by Android's `BitmapFactory` (typically JPEG/PNG/WebP). DNG/RAW sensor decoding is **not implemented**. Add a RAW decoder such as a vetted LibRaw-based Android integration to support true camera RAW files.
- The `Sharpen` control currently selects a sharpening-style preset label/strength but a convolution/unsharp-mask implementation is still needed for actual pixel sharpening.
- The `Denoise` slider is present in the UI but a real denoising algorithm is not yet wired into the pixel pipeline.
- Offline "AI" is a lightweight local heuristic, not a neural network model. For genuine on-device AI, integrate a tested TensorFlow Lite model.
- Online AI is an integration interface only. Configure your own HTTPS backend and authentication; do not embed private API keys in the APK.
- The De-Log preset is a generic contrast/saturation look, not a camera-specific log-to-Rec.709 transform. Choose the correct input camera/log profile and transform for accurate results.
- Editing is performed on a preview-sized bitmap (maximum width 1800 px); export uses that preview bitmap, not full-resolution RAW data.
- For production, add background processing, memory safeguards, crop/rotate, undo history, full-resolution export, metadata handling, tests, and privacy disclosures.

## Project structure
- `app/src/main/java/com/rawstudio/app/MainActivity.kt` — Compose UI, preview editor, basic pixel adjustments and export.
- `app/src/main/java/com/rawstudio/app/AiEnhancer.kt` — online AI service integration contract and security notes.
